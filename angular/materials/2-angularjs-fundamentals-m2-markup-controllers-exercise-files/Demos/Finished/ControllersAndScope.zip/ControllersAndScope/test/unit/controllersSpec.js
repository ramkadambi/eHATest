'use strict';

/* jasmine specs for controllers go here */

